// Manejo de navegación SPA
let navLinks = document.querySelectorAll('.nav-link');
let sections = document.querySelectorAll('.section');
let menuIcon = document.getElementById('menuIcon');
let navLinksContainer = document.getElementById('navLinks');

/*Supondremos que se tiene a los siguientes usuarios registrados:*/
let usuarios=[
    {
        userName:"peredo_ac",
        password:"Aprobado16*"
    },
    {
        userName: "fede_villca",
        password: "Aprobado17*"
    },
    {
        userName:"juan_sanchez",
        password:"Admin123*"
    },
    {
        userName:"ana_veizaga",
        password:"Vendedor123."
    },
    {
        userName: "incos",
        password: "Incos10."
    }
]


// Toggle para el menú hamburguesa en móviles
menuIcon.addEventListener('click', () => {
    navLinksContainer.classList.toggle('show');
});

// Navegación SPA
navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();

        // Remover clase 'active' de todas las secciones
        sections.forEach(section => section.classList.remove('active'));

        // Ocultar el menú en móviles después de seleccionar una opción
        navLinksContainer.classList.remove('show');

        // Obtener el destino desde el data-target del enlace clicado
        const targetSection = document.getElementById(this.getAttribute('data-target'));

        // Agregar clase 'active' a la sección correspondiente
        targetSection.classList.add('active');
    });
});

function abrirPagina(){
    // Abrir una nueva página
    var nuevaVentana = window.open("acceso.html", "_blank");

    // Verificar que la ventana se haya abierto correctamente
    if (nuevaVentana) {
        // Darle foco a la nueva ventana
        nuevaVentana.focus();
    } else {
        // Si la ventana no se puede abrir (por ejemplo, bloqueadores de popups)
        alert("Por favor, permite las ventanas emergentes para abrir la página.");
    }    
}

/*
El password deberá tener como mínimo 8 caracteres
Por lo menos una letra minúscula, una letra mayúscula, un número, y un carácter especial
*/
function validarPassword(password){
   /*
    Una expresión regular está delimitada por el símbolo /, el acento circunflejo representa 
    el inicio de la cadena y el símbolo $ representa el final de la cadena. 
    */
    var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/;    
    return (regex.test(password))
}

/*
El nombre de usuario debe cumplir con las siguientes condiciones:
- Longitud: Debe tener entre 3 y 15 caracteres.
- Carácteres permitidos: Letras (mayúsculas y minúsculas), números, guiones bajos (_) y puntos (.).
- No puede empezar ni terminar con un punto o guion bajo.
- No puede contener puntos o guiones bajos consecutivos.
- No se permiten espacios en blanco ni caracteres especiales.
*/
function validarUsuario(usuario){
    /*
    Una expresión regular está delimitada por el símbolo /, el acento circunflejo representa 
    el inicio de la cadena y el símbolo $ representa el final de la cadena. 
    */
    var regex = /^([a-zA-Z0-9]+[._]?[a-zA-Z0-9]+){2,14}$/;
    return (regex.test(usuario))
}

function usuarioRegistrado(usuario, password){
    for (let i = 0; i < usuarios.length; i++) {
        if (usuarios[i].userName === usuario && usuarios[i].password === password) {
          return true; // Si coincide, retorna verdadero
        }
    }
    return false; // Si no encuentra coincidencia, retorna falso
}

function validarDatos(usuario, password){
    if (validarUsuario(usuario))
        if (validarPassword(password))
            if (usuarioRegistrado(usuario, password))
                alert("Datos Válidos. Bienvenido al sistema")
            else
                alert("No existe un usurio con los credenciales proporcionados")
        else
            alert("Password no válido")
    else
        alert("Nombre de usuario no válido")
}